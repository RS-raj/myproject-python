# from django import forms

# from myproject.home.models import Contact

# class ContactForm(forms.ModelForm):
#     class Meta:
#         model = Contact
#         widgets = {
#            'password': forms.PasswordInput(),
#         }